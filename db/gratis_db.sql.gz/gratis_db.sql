-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 11, 2018 at 06:29 PM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 7.2.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gratis_db`
--
CREATE DATABASE IF NOT EXISTS `gratis_db` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `gratis_db`;

-- --------------------------------------------------------

--
-- Table structure for table `dealer`
--

CREATE TABLE `dealer` (
  `id` int(11) NOT NULL,
  `dealer_name` varchar(50) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(2) NOT NULL,
  `zip` varchar(5) NOT NULL,
  `phone` varchar(12) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dealer`
--

INSERT INTO `dealer` (`id`, `dealer_name`, `address`, `city`, `state`, `zip`, `phone`, `email`) VALUES
(1, 'Long of Chattanooga', '6035 International Dr', 'Chattanooga', 'TN', '37421', '423.226.0624', 'sales@longofchatt.com');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `id` int(11) NOT NULL,
  `dealer_id` int(11) NOT NULL,
  `image_url` varchar(500) NOT NULL,
  `year` varchar(4) NOT NULL,
  `make` varchar(50) NOT NULL,
  `model` varchar(50) NOT NULL,
  `msrp` varchar(12) NOT NULL,
  `price` varchar(12) NOT NULL,
  `stock_no` varchar(10) NOT NULL,
  `vin` varchar(17) NOT NULL,
  `type` varchar(4) NOT NULL,
  `mileage` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`id`, `dealer_id`, `image_url`, `year`, `make`, `model`, `msrp`, `price`, `stock_no`, `vin`, `type`, `mileage`) VALUES
(2, 1, 'elantra-1.jpg', '2018', 'Hyundai', 'Elantra', '$21,974', '$21,974', '041378', 'KMHH35LE4JU041378', 'New', '6'),
(7, 1, 'images/accent-1.jpg', '2018', 'Hyundai', 'Accent', '$17,619', '$17,619', '020137', '3KPC24A34JE020137', 'New', '138'),
(8, 1, 'images/sonata-1.jpg', '2018', 'Hyundai', 'Sonata', '$34,059', '$34,059', '666502', '5NPE34AB8JH666502', 'New', '15');

-- --------------------------------------------------------

--
-- Table structure for table `inventory_details`
--

CREATE TABLE `inventory_details` (
  `id` int(11) NOT NULL,
  `inventory_id` int(11) NOT NULL,
  `series` varchar(50) NOT NULL,
  `trim` varchar(4) NOT NULL,
  `ext_color` varchar(50) NOT NULL,
  `body_style` varchar(50) NOT NULL,
  `engine` varchar(40) NOT NULL,
  `certified` varchar(12) NOT NULL,
  `transmission` varchar(1000) NOT NULL,
  `restraints` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `inventory_details`
--

INSERT INTO `inventory_details` (`id`, `inventory_id`, `series`, `trim`, `ext_color`, `body_style`, `engine`, `certified`, `transmission`, `restraints`) VALUES
(1, 2, 'GT', 'Base', 'Summit White', '4d Hatchback', '2.0L 4-Cylinder', 'N', 'Automatic', 'Air Bags'),
(3, 7, 'SE', 'SE', 'Silver', '4d Sedan', '1.6L 4-Cylinder', 'N', '6 Spd Automatic', 'Air Bags'),
(4, 8, 'Limited 2.0T', 'Limi', 'Phantom Black', '4d Sedan', '2.0L 4-Cylinder Turbo', 'N', '8 Spd Automatic', 'Air Bags');

-- --------------------------------------------------------

--
-- Table structure for table `inventory_images`
--

CREATE TABLE `inventory_images` (
  `id` int(11) NOT NULL,
  `inventory_id` int(11) NOT NULL,
  `image1` varchar(500) NOT NULL,
  `image2` varchar(500) NOT NULL,
  `image3` varchar(500) NOT NULL,
  `image4` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `inventory_images`
--

INSERT INTO `inventory_images` (`id`, `inventory_id`, `image1`, `image2`, `image3`, `image4`) VALUES
(1, 2, 'elantra-1.jpg', 'elantra-2.jpg', 'elantra-3.jpg', 'elantra-4.jpg'),
(2, 7, 'accent-1.jpg', 'accent-2.jpg', 'accent-3.jpg', 'accent-4.jpg'),
(3, 8, 'sonata-1.jpg', 'sonata-2.jpg', 'sonata-3.jpg', 'sonata-4.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `inventory_options`
--

CREATE TABLE `inventory_options` (
  `id` int(11) NOT NULL,
  `inventory_id` int(11) NOT NULL,
  `options` varchar(5000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `inventory_options`
--

INSERT INTO `inventory_options` (`id`, `inventory_id`, `options`) VALUES
(2, 2, '17x7 Alloy Wheels,Front Bucket Seats,Premium Cloth Seating Surfaces,Radio: AM/FM/HD Radio/SiriusXM Audio System,Cargo Net,Mud Guards,Carpeted Floor Mats,4-Wheel Disc Brakes,6 Speakers,Air Conditioning,Electronic Stability Control,Front Center Armrest,Spoiler,Tachometer,ABS brakes,Brake assist,Bumpers: body-color,Delay-off headlights,Driver door bin,Driver vanity mirror,Dual front impact airbags,Dual front side impact airbags,Front anti-roll bar,Front reading lights,Front wheel independent suspension,Fully automatic headlights,Heated door mirrors,Illuminated entry,Knee airbag,Low tire pressure warning,Occupant sensing airbag,Outside temperature display,Overhead airbag,Overhead console,Panic alarm,Passenger door bin,Passenger vanity mirror,Power door mirrors,Power steering,Power windows,Rear reading lights,Rear seat center armrest,Rear window defroster,Rear window wiper,Remote keyless entry,Security system,Speed control,Speed-sensing steering,Split folding rear seat,Steering wheel mounted audio controls,Telescoping steering wheel,Tilt steering wheel,Traction control,Trip computer,Variably intermittent wipers,AM/FM radio: SiriusXM,Display: analog,Exterior Parking Camera Rear'),
(3, 7, '15 Steel Wheels w/Covers,Front Bucket Seats,Cloth Seat Trim,Radio: Audio 4.0B AM/FM,Cargo Net,Mudguards,Carpeted Floor Mats,4 Speakers,Air Conditioning,Electronic Stability Control,Tachometer,ABS brakes,AM/FM radio,Anti-whiplash, front head restraints,Brake assist,Bumpers: body-color,CD player,Driver door bin,Driver vanity mirror,Dual front impact airbags,Dual front side impact airbags,Front anti-roll bar,Front reading lights,Front wheel independent suspension,Illuminated entry,Low tire pressure warning,Occupant sensing airbag,Overhead airbag,Overhead console,Panic alarm,Passenger door bin,Passenger vanity mirror,Power door mirrors,Power steering,Power windows,Rear window defroster,Remote keyless entry,Speed control,Speed-sensing steering,Split folding rear seat,Steering wheel mounted audio controls,Tilt steering wheel,Traction control,Trip computer,Door mirrors: body-color,Exterior Parking Camera Rear'),
(4, 8, 'Wheels: 18 x 7.5J Dark Aluminum Alloy,Heated/Ventilated Front Sport Seats,Leather Seating Surfaces w/Contrast Stitching,Radio: AM/FM/HD/SiriusXM/MP3 Infinity Prem Audio,First Aid Kit,Cargo Net,Rear Bumper Applique,Reversible Cargo Tray,Carpeted Floor Mats,4-Wheel Disc Brakes,9 Speakers,Air Conditioning,Electronic Stability Control,Front Bucket Seats,Front Center Armrest,Leather Shift Knob,Navigation System,Rear Parking Sensors,Tachometer,ABS brakes,Automatic temperature control,Brake assist,Bumpers: body-color,Delay-off headlights,Driver door bin,Driver vanity mirror,Dual front impact airbags,Dual front side impact airbags,Emergency communication system,Four wheel independent suspension,Front anti-roll bar,Front dual zone A/C,Front reading lights,Fully automatic headlights,Garage door transmitter: HomeLink,Heated door mirrors,Heated front seats,Heated steering wheel,Illuminated entry,Knee airbag,Leather steering wheel,Low tire pressure warning,Memory seat,Occupant sensing airbag,Outside temperature display,Overhead airbag,Overhead console,Panic alarm,Passenger door bin,Passenger vanity mirror,Power door mirrors,Power driver seat,Power moonroof,Power passenger seat,Power steering,Power windows,Rear anti-roll bar,Rear reading lights,Rear seat center armrest,Rear window defroster,Remote keyless entry,Security systemSpeed control,Speed-sensing steering,Split folding rear seat,Sport steering wheel,Steering wheel mounted audio controls,Sun blinds,Telescoping steering wheel,Tilt steering wheel,Traction control,Trip computer,Turn signal indicator mirrors,Variably intermittent wipers,Ventilated front seats,Front beverage holders,Auto-dimming Rear-View mirror,Distance-Pacing Cruise Control,Lane Departure Warning System,Speed-Sensitive Wipers,Compass,AM/FM radio: SiriusXM,Exterior Parking Camera Rear,Auto High-beam Headlights,Blind spot sensor: Blind Spot Detection (BSD) with Lane Change Assist (LCA) warning');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `created_at`) VALUES
(1, 'knox', '$2y$10$GUtgrEs8jcBCFB.JEJQvMusL9XYQzSkn9l8vBrx2uK8LvHMbZLDQ2', '2018-06-09 19:25:12');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dealer`
--
ALTER TABLE `dealer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`id`),
  ADD KEY `dealer_id` (`dealer_id`) USING BTREE;

--
-- Indexes for table `inventory_details`
--
ALTER TABLE `inventory_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `inventory_id` (`inventory_id`) USING BTREE;

--
-- Indexes for table `inventory_images`
--
ALTER TABLE `inventory_images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `inventory_id` (`inventory_id`) USING BTREE;

--
-- Indexes for table `inventory_options`
--
ALTER TABLE `inventory_options`
  ADD PRIMARY KEY (`id`),
  ADD KEY `inventory_id` (`inventory_id`) USING BTREE;

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dealer`
--
ALTER TABLE `dealer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `inventory_details`
--
ALTER TABLE `inventory_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `inventory_images`
--
ALTER TABLE `inventory_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `inventory_options`
--
ALTER TABLE `inventory_options`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `inventory`
--
ALTER TABLE `inventory`
  ADD CONSTRAINT `inventory_ibfk_1` FOREIGN KEY (`dealer_id`) REFERENCES `dealer` (`id`);

--
-- Constraints for table `inventory_details`
--
ALTER TABLE `inventory_details`
  ADD CONSTRAINT `inventory_details_ibfk_1` FOREIGN KEY (`inventory_id`) REFERENCES `inventory` (`id`);

--
-- Constraints for table `inventory_images`
--
ALTER TABLE `inventory_images`
  ADD CONSTRAINT `inventory_images_ibfk_1` FOREIGN KEY (`inventory_id`) REFERENCES `inventory` (`id`);

--
-- Constraints for table `inventory_options`
--
ALTER TABLE `inventory_options`
  ADD CONSTRAINT `inventory_options_ibfk_1` FOREIGN KEY (`inventory_id`) REFERENCES `inventory` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
